#!/bin/sh
sudo /pkmj/activemq_61616/apache-activemq/bin/activemq stop
sudo sleep 2s
