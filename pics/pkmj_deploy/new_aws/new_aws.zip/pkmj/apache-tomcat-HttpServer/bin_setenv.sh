#! /bin/sh
export JAVA_OPTS="-server -Xms1G -Xmx1G -Dfpp_store.image.absolute.path=/pokermahjong/webapps/ROOT"
