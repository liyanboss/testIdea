#!/bin/sh
sudo /pkmj/activemq_61626/apache-activemq/bin/activemq stop
sudo sleep 2s
