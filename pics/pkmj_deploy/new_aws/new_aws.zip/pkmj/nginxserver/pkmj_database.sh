#!/bin/sh
#mysql -hlocalhost -uroot -proot pokermahjong
#mysql --host=192.168.86.60 --user=root --password=123123 --database=pokermahjong
mysql --host=192.168.86.66 --user=mahjonguser --password=mahjongpwd --database=pokermahjong
#mysql --host=192.168.86.60 --user=mahjonguser --password=mahjongpwd --database=pokermahjong
