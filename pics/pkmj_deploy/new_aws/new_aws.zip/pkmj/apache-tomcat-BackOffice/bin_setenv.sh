#! /bin/sh
export JAVA_OPTS="-server -Xms1G -Xmx1G"
