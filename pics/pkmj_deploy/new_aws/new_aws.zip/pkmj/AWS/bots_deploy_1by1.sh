#!/bin/sh
sudo /pkmj/airobot_niuniu/scripts/deploy.sh
echo '------------------------- airobot_niuniu deploy done -------------------------'
sudo /pkmj/airobot_dmqq/scripts/deploy.sh
echo '------------------------- airobot_dmqq deploy done -------------------------'
sudo /pkmj/airobot_txhd/scripts/deploy.sh
echo '------------------------- airobot_txhd deploy done -------------------------'
sudo /pkmj/airobot_tlmn/scripts/deploy.sh
echo '------------------------- airobot_tlmn deploy done -------------------------'
sudo /pkmj/airobot_pkdn/scripts/deploy.sh
echo '------------------------- airobot_pkdn deploy done -------------------------'
sudo /pkmj/airobot_bcmn/scripts/deploy.sh
echo '------------------------- airobot_bcmn deploy done -------------------------'
sudo /pkmj/airobot_ggth/scripts/deploy.sh
echo '------------------------- airobot_ggth deploy done -------------------------'
sudo /pkmj/airobot_rmin/scripts/deploy.sh
echo '------------------------- airobot_rmin deploy done -------------------------'
sudo /pkmj/airobot_ddzb/scripts/deploy.sh
echo '------------------------- airobot_ddzb deploy done -------------------------'
sudo /pkmj/airobot_big2/scripts/deploy.sh
echo '------------------------- airobot_big2 deploy done -------------------------'
