#!/bin/sh
sudo /pkmj/airobot_niuniu/scripts/shutdown.sh
echo '------------------------- airobot_niuniu shutdown done -------------------------'
sudo /pkmj/airobot_dmqq/scripts/shutdown.sh
echo '------------------------- airobot_dmqq shutdown done -------------------------'
sudo /pkmj/airobot_txhd/scripts/shutdown.sh
echo '------------------------- airobot_txhd shutdown done -------------------------'
echo sudo /pkmj/airobot_tlmn/scripts/shutdown.sh
echo '------------------------- airobot_tlmn shutdown done -------------------------'
sudo /pkmj/airobot_pkdn/scripts/shutdown.sh
echo '------------------------- airobot_pkdn shutdown done -------------------------'
sudo /pkmj/airobot_bcmn/scripts/shutdown.sh
echo '------------------------- airobot_bcmn shutdown done -------------------------'
sudo /pkmj/airobot_ggth/scripts/shutdown.sh
echo '------------------------- airobot_ggth shutdown done -------------------------'
echo sudo /pkmj/airobot_rmin/scripts/shutdown.sh
echo '------------------------- airobot_rmin shutdown done -------------------------'
echo sudo /pkmj/airobot_ddzb/scripts/shutdown.sh
echo '------------------------- airobot_ddzb shutdown done -------------------------'
echo sudo /pkmj/airobot_big2/scripts/shutdown.sh
echo '------------------------- airobot_big2 shutdown done -------------------------'
