#!/bin/sh
echo '------------------------- start: delete all upload -------------------------'
sudo rm -rf /pkmj/httpserver/upload/*
sudo rm -rf /pkmj/lobbyserver/upload/*
sudo rm -rf /pkmj/gameserver/upload/*
sudo rm -rf /pkmj/backoffice/upload/*
sudo rm -rf /pkmj/newbackoffice/upload/*
echo '------------------------- finish: delete all upload -------------------------'


echo '------------------------- start: delete all upload -------------------------'
sudo rm -rf /pkmj/airobot_niuniu/upload/*
sudo rm -rf /pkmj/airobot_dmqq/upload/*
sudo rm -rf /pkmj/airobot_txhd/upload/*
sudo rm -rf /pkmj/airobot_tlmn/upload/*
sudo rm -rf /pkmj/airobot_pkdn/upload/*
sudo rm -rf /pkmj/airobot_bcmn/upload/*
sudo rm -rf /pkmj/airobot_ggth/upload/*
sudo rm -rf /pkmj/airobot_rmin/upload/*
sudo rm -rf /pkmj/airobot_ddzb/upload/*
sudo rm -rf /pkmj/airobot_big2/upload/*
sudo rm -rf /pkmj/dataconsolidate/upload/*
echo '------------------------- finish: delete all upload -------------------------'
