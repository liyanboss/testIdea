#!/bin/sh
sudo /pkmj/airobot_niuniu/scripts/startup.sh
echo '------------------------- airobot_niuniu startup done -------------------------'
sudo /pkmj/airobot_dmqq/scripts/startup.sh
echo '------------------------- airobot_dmqq startup done -------------------------'
sudo /pkmj/airobot_txhd/scripts/startup.sh
echo '------------------------- airobot_txhd startup done -------------------------'
echo sudo /pkmj/airobot_tlmn/scripts/startup.sh
echo '------------------------- airobot_tlmn startup done -------------------------'
sudo /pkmj/airobot_pkdn/scripts/startup.sh
echo '------------------------- airobot_pkdn startup done -------------------------'
sudo /pkmj/airobot_bcmn/scripts/startup.sh
echo '------------------------- airobot_bcmn startup done -------------------------'
sudo /pkmj/airobot_ggth/scripts/startup.sh
echo '------------------------- airobot_ggth startup done -------------------------'
echo sudo /pkmj/airobot_rmin/scripts/startup.sh
echo '------------------------- airobot_rmin startup done -------------------------'
echo sudo /pkmj/airobot_ddzb/scripts/startup.sh
echo '------------------------- airobot_ddzb startup done -------------------------'
echo sudo /pkmj/airobot_big2/scripts/startup.sh
echo '------------------------- airobot_big2 startup done -------------------------'
