#!/bin/sh
sudo /pkmj/airobot_niuniu/scripts/backup.sh
echo '------------------------- airobot_niuniu backup done -------------------------'
sudo /pkmj/airobot_dmqq/scripts/backup.sh
echo '------------------------- airobot_dmqq backup done -------------------------'
sudo /pkmj/airobot_txhd/scripts/backup.sh
echo '------------------------- airobot_txhd backup done -------------------------'
sudo /pkmj/airobot_tlmn/scripts/backup.sh
echo '------------------------- airobot_tlmn backup done -------------------------'
sudo /pkmj/airobot_pkdn/scripts/backup.sh
echo '------------------------- airobot_pkdn backup done -------------------------'
sudo /pkmj/airobot_bcmn/scripts/backup.sh
echo '------------------------- airobot_bcmn backup done -------------------------'
sudo /pkmj/airobot_ggth/scripts/backup.sh
echo '------------------------- airobot_ggth backup done -------------------------'
sudo /pkmj/airobot_rmin/scripts/backup.sh
echo '------------------------- airobot_rmin backup done -------------------------'
sudo /pkmj/airobot_ddzb/scripts/backup.sh
echo '------------------------- airobot_ddzb backup done -------------------------'
sudo /pkmj/airobot_big2/scripts/backup.sh
echo '------------------------- airobot_big2 backup done -------------------------'
